package payment;

import java.util.LinkedList;
import java.util.Queue;


public class PaymentQueueDemonstrate {

     public static void queueDemonstration() {
        // Create a generic queue for payment 
        Queue<PaymentMethod> paymentQueue = new LinkedList<>();

        // Enqueue payment 
        paymentQueue.offer(new CreditCard("4322-8965-2181-1219", 700.0));
        paymentQueue.offer(new Cash(300.0));

        while (!paymentQueue.isEmpty()) {
            PaymentMethod paymentMethod = paymentQueue.poll();
            System.out.println("Dequeued Payment Method: " + paymentMethod.getClass().getSimpleName());
        }
        

    }
}
