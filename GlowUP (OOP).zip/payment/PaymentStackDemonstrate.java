package payment;

import java.util.Stack;

public class PaymentStackDemonstrate {

    public static void stackDemonstration() {
        // Create a generic stack for payment
        Stack<PaymentMethod> paymentStack = new Stack<>();

        // Add payment 
        paymentStack.push(new CreditCard("1219-3356-9151-8121", 500.0));
        paymentStack.push(new Cash(200.0));

        for (PaymentMethod paymentMethod : paymentStack) {
            System.out.println("Payment Method: " + paymentMethod.getClass().getSimpleName());
        }

        while (!paymentStack.isEmpty()) {
            PaymentMethod paymentMethod = paymentStack.pop();
            System.out.println("Popped Payment Method: " + paymentMethod.getClass().getSimpleName());
        }

    }
}
