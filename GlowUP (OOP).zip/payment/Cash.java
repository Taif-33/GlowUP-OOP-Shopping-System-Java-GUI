package payment;

public class Cash extends PaymentMethod {
    public Cash(double cashAmount) {
        super(cashAmount);
    }

    @Override
    public void makePayment(double amount) {
        if (this.getAmount() >= amount) {
            super.makePayment(amount);
            System.out.println("Payment of $" + amount + " made in cash");
        } else {
            System.out.println("Insufficient cash for payment.");
        }
    }
}
