package payment;

public interface Purchasable {
    double getAmount();
    void makePayment(double amount);
}
