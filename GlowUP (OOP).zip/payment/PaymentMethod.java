package payment;

public abstract class PaymentMethod implements Purchasable {
    double amount;

    public PaymentMethod(double amount) {
        this.amount = amount;
    }

    @Override
    public double getAmount() {
        return amount;
    }

    @Override
    public void makePayment(double amount) {
        if (this.amount >= amount) {
            System.out.println("Payment of $" + amount + " made with this method.");
            this.amount -= amount;
        } else {
            System.out.println("Insufficient funds for payment.");
        }
    }
}
