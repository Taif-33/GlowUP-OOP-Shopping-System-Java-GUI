package payment;

import java.util.HashMap;
import java.util.Map;

public class PaymentHashMapDemonstrate {
    
    public static Map<String, PaymentMethod> hashMapDemonstration() {
        // Create a HashMap 
        Map<String, PaymentMethod> paymentMap = new HashMap<>();

        // Add payment methods to the HashMap
        paymentMap.put("CreditCard1", new CreditCard("1342-3265-4773-8484", 1000.0));
        paymentMap.put("Cash1", new Cash(500.0));

        paymentMap.put("CreditCard2", new CreditCard("1255-6956-7437-4848", 800.0)); 
        paymentMap.put("Cash2", new Cash(800.0)); 

        return paymentMap;
    }
}

