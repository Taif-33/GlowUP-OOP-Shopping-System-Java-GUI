package payment;

public class CreditCard extends PaymentMethod {
    private String cardNumber;

    public CreditCard(String cardNumber, double amount) {
        super(amount);
        this.cardNumber = cardNumber;
    }

    public String getCardNumber() {
        return cardNumber;
    }

    @Override
    public void makePayment(double amount) {
        if (this.getAmount() >= amount) {
            super.makePayment(amount);
            System.out.println("Payment of $" + amount + " made with credit card " + cardNumber);
        } else {
            System.out.println("Insufficient funds for payment.");
        }
    }
}
