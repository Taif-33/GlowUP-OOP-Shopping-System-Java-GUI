package customerServices;

import items.Product;

public class Shop extends Order implements Shipping {
    public Shop(Product productName, int quantity, Shipping OrderMethod) {
        super(productName, quantity, OrderMethod);
    }

    @Override
    public double TotalCost() {
        return productName.getPrice() * quantity;
    }

    @Override
    public void deliverProduct() {
        System.out.println("Delivering product: " + productName.getProductName());
    }

}
