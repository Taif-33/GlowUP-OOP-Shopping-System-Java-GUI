package customerServices;

public class shippingCom implements Shipping {
    @Override
    public void shipProduct() {
        System.out.println("Product shipped via standard shipping.");
    }

    @Override
    public void deliverProduct() {
        System.out.println("Delivering product using standard shipping");
    }
}
