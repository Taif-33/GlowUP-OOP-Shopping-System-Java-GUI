package customerServices;

import items.Product;

public abstract class Order implements ordercost {
    public Product productName;
    public int quantity;
    protected Shipping shippingMethod;

    protected Order(Product productName, int quantity, Shipping shippingMethod) {
        this.productName = productName;
        this.quantity = quantity;
        this.shippingMethod = shippingMethod;
    }

    @Override
    public double TotalCost() {
        return productName.getPrice() * quantity;
    }

    public void shipProduct() {
        System.out.println("Shipping the product.");
    }

    public static Order createOrder(Product productName, int quantity, Shipping shippingMethod) {
        return new Order(productName, quantity, shippingMethod) {
            
        };
    }
}
