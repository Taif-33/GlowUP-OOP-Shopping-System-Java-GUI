package items;

public class Clothes {
    public String designer;
    protected String itemType;
    public String brand;
    public double price;
    public String size;
    public String color;

    public Clothes(String designer, String itemType, String brand, double price, String size, String color) {
        this.designer = designer;
        this.itemType = itemType;
        this.brand = brand;
        this.price = price;
        this.size = size;
        this.color = color;
    }

    public String toString() {
        return "Clothes: " + this.designer + ", " + this.itemType + ", " + this.brand + " , Color: " + this.color + " , Size: " + this.size + " , Price: $" + this.price;
    }  

    public String getDesigner() {
        return designer;
    }

    public String getItemType() {
        return itemType;
    }
    

    public String getBrand() {
        return brand;
    }

    public double getPrice() {
        return price;
    }

    public String getSize() {
        return size;
    }

    public String getColor() {
        return color;
    }
}
