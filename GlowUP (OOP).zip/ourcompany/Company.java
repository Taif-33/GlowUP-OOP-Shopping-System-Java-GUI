package ourcompany;

public class Company {
    public String companyName;
    public String companyAddress;
    private int hasEmployee;
    protected int hasOrder;

    public Company(String companyName, String companyAddress, int hasEmployee, int hasOrder) {
        this.companyName = companyName;
        this.companyAddress = companyAddress;
        this.hasEmployee = hasEmployee;
        this.hasOrder = hasOrder;
    }
    public void displayCompanyInfo() { 
        System.out.println("Company Name: " + companyName); 
        System.out.println("Company Address: " + companyAddress); 
        System.out.println("Number of Employees: " + hasEmployee); 
        System.out.println("Number of Orders: " + hasOrder); 
    } 

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        if (companyName != null && !companyName.isEmpty()) {
            this.companyName = companyName;
        } else {
            System.out.println("Invalid company name.");
        }
    }

    public String getCompanyAddress() {
        return companyAddress;
    }

    public void setCompanyAddress(String companyAddress) {
        if (companyAddress != null && !companyAddress.isEmpty()) {
            this.companyAddress = companyAddress;
        } else {
            System.out.println("Invalid company address.");
        }
    }

    public int getHasEmployee() {
        return hasEmployee;
    }

    public void setHasEmployee(int hasEmployee) {
        if (hasEmployee >= 0) {
            this.hasEmployee = hasEmployee;
        } else {
            System.out.println("Invalid number of employees.");
        }
    }

    public int getHasOrder() {
        return hasOrder;
    }

    public void setHasOrder(int hasOrder) {
        if (hasOrder >= 0) {
            this.hasOrder = hasOrder;
        } else {
            System.out.println("Invalid number of orders.");
        }
    }
}
