package ourcompany;

public class Administration {
    public String managerName;
    protected String department;

    public Administration(String managerName, String department) {
        this.managerName = managerName;
        this.department = department;
    }

    public String getManagerName() {
        return managerName;
    }

    public String getDepartment() {
        return department;
    }

    public void performAdministrativeTasks() {
        System.out.println(managerName + " is performing administrative tasks in the " + department + " department.");
    }

    public void setManagerName(String managerName) {
        if (managerName != null && !managerName.isEmpty()) {
            this.managerName = managerName;
        } else {
            System.out.println("Invalid manager name.");
        }
    }

    public void setDepartment(String department) {
        if (department != null && !department.isEmpty()) {
            this.department = department;
        } else {
            System.out.println("Invalid department name.");
        }
    }
}
